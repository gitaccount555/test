export const storeProducts = [
  
  {
    id: 1,
    title: "Ceramic Taper Holder - Earth",
    img: "https://assets.weimgs.com/weimgs/rk/images/wcm/products/202040/0883/ceramic-taper-holder-earth-2-m.jpg",
    price: 56.1,
    info: 'Lorem ipsum dolor amet offal butcher quinoa sustainable gastropub, echo park actually green juice sriracha paleo. Brooklyn sriracha semiotics, DIY coloring book mixtape craft beer sartorial hella blue bottle. Tote bag wolf authentic try-hard put a bird on it mumblecore. Unicorn lumbersexual master cleanse blog hella VHS, vaporware sartorial church-key cardigan single-origin coffee lo-fi organic asymmetrical. Taxidermy semiotics celiac stumptown scenester normcore, ethical helvetica photo booth gentrify."'

  },
  {
    id: 2,
    title: "Frog Vase Taper Holder",
    img: "https://assets.weimgs.com/weimgs/rk/images/wcm/products/202040/0883/frog-vase-taper-holder-m.jpg",
    price: 114.4,
    info: 'Lorem ipsum dolor amet offal butcher quinoa sustainable gastropub, echo park actually green juice sriracha paleo. Brooklyn sriracha semiotics, DIY coloring book mixtape craft beer sartorial hella blue bottle. Tote bag wolf authentic try-hard put a bird on it mumblecore. Unicorn lumbersexual master cleanse blog hella VHS, vaporware sartorial church-key cardigan single-origin coffee lo-fi organic asymmetrical. Taxidermy semiotics celiac stumptown scenester normcore, ethical helvetica photo booth gentrify."'
  },
  {
    id: 3,
    title: "Petite Taper Holder - Cylinder",
    img: "https://assets.weimgs.com/weimgs/ab/images/wcm/products/202040/0883/petite-taper-holder-cylinder-2-m.jpg",
    price: 30.8,
    info: 'Lorem ipsum dolor amet offal butcher quinoa sustainable gastropub, echo park actually green juice sriracha paleo. Brooklyn sriracha semiotics, DIY coloring book mixtape craft beer sartorial hella blue bottle. Tote bag wolf authentic try-hard put a bird on it mumblecore. Unicorn lumbersexual master cleanse blog hella VHS, vaporware sartorial church-key cardigan single-origin coffee lo-fi organic asymmetrical. Taxidermy semiotics celiac stumptown scenester normcore, ethical helvetica photo booth gentrify."'
  },

  {
    id: 4,
    title: " Colored Taper Candles",
    img: "https://assets.weimgs.com/weimgs/ab/images/wcm/products/202040/0883/12-colored-taper-candles-m.jpg",
    price: 106,
    info: 'Lorem ipsum dolor amet offal butcher quinoa sustainable gastropub, echo park actually green juice sriracha paleo. Brooklyn sriracha semiotics, DIY coloring book mixtape craft beer sartorial hella blue bottle. Tote bag wolf authentic try-hard put a bird on it mumblecore. Unicorn lumbersexual master cleanse blog hella VHS, vaporware sartorial church-key cardigan single-origin coffee lo-fi organic asymmetrical. Taxidermy semiotics celiac stumptown scenester normcore, ethical helvetica photo booth gentrify."'
  },

  {
    id: 5,
    title: "Fancy Taper Candles",
    img: "https://assets.weimgs.com/weimgs/ab/images/wcm/products/202040/0883/10-fancy-taper-candles-m.jpg",
    price: 22,
    info: 'Lorem ipsum dolor amet offal butcher quinoa sustainable gastropub, echo park actually green juice sriracha paleo. Brooklyn sriracha semiotics, DIY coloring book mixtape craft beer sartorial hella blue bottle. Tote bag wolf authentic try-hard put a bird on it mumblecore. Unicorn lumbersexual master cleanse blog hella VHS, vaporware sartorial church-key cardigan single-origin coffee lo-fi organic asymmetrical. Taxidermy semiotics celiac stumptown scenester normcore, ethical helvetica photo booth gentrify."'

  },
  {
    id: 6,
    title: "Fancy Pillar Candles",
    img: "https://assets.weimgs.com/weimgs/ab/images/wcm/products/202041/0001/3-fancy-pillar-candles-m.jpg",
    price: 36.5

  },
  {
    id: 7,
    title: "Filled Candles",
    img: "https://assets.weimgs.com/weimgs/ab/images/wcm/products/202040/0883/filled-candles-m.jpg",
    price: 62

  },

];

export const detailProduct = {
  id: 1,
  title: "1234",
  img: "https://assets.weimgs.com/weimgs/rk/images/wcm/products/202040/0883/ceramic-taper-holder-earth-2-m.jpg",
  price: 10,
  info:
    "Lorem ipsum dolor amet offal butcher quinoa sustainable gastropub, echo park actually green juice sriracha paleo. Brooklyn sriracha semiotics, DIY coloring book mixtape craft beer sartorial hella blue bottle. Tote bag wolf authentic try-hard put a bird on it mumblecore. Unicorn lumbersexual master cleanse blog hella VHS, vaporware sartorial church-key cardigan single-origin coffee lo-fi organic asymmetrical. Taxidermy semiotics celiac stumptown scenester normcore, ethical helvetica photo booth gentrify.",
  count: 0,
  total: 0
};
